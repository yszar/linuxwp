=== Plugin Name ===
Contributors: Showfom
Donate link: http://showfom.com/auto-hishslide-wordpress-plugin/
Tags: highslide, images, auto
Requires at least: 2.0.2
Tested up to: 2.8
Stable tag: trunk

This plugin automatically add HighSlide Image Effect in your blog and You don't Need To Change Anything!

== Description ==
1.This plugin automatically add HighSlide Image Effect in your blog and You don't Need To Change Anything! 

2.You don't need to install HighSlide4WP if you only want to use the images effect of HighSlide.

3.If you install HighSlide4WP, just uninstall it.

4.If you want to use other effect of HighSlide , please use <a href="http://wordpress.org/extend/plugins/highslide4wp/">HighSlide4WP</a> with <a href="http://wordpress.org/extend/plugins/add-highslide/">Add Highslide</a>.

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `auto-highslide` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress



== Frequently Asked Questions ==

= How to know me =

<a href="http://showfom.com/contact/">Just contact me.</a>


== Screenshots ==

1.  `/trunk/screenshot-1.png`