<?php
/**
 * @package qiniu Support
 * @version 1.0.0
 */
/*
Plugin Name: 七牛云存储
Plugin URI: http://club.veigen.com/qiniu-for-wordpress/4478.html
Description: 上传附件至七牛云存储(qiniu Cloud)。This is a plugin for qiniu.
Author: veigen
Version: 1.0.0
Author URI: http://club.veigen.com
*/
error_reporting(E_ALL & ~ E_NOTICE); 
	require_once('vendor/autoload.php');
	use Qiniu\Auth;
    use Qiniu\Storage\BucketManager;
	use Qiniu\Storage\UploadManager;


if ( !defined('WP_PLUGIN_URL') )
	define( 'WP_PLUGIN_URL', WP_CONTENT_URL . '/plugins' ); //  plugin url

define('QINIU_BASENAME', plugin_basename(__FILE__));
define('QINIU_BASEFOLDER', plugin_basename(dirname(__FILE__)));
define('QINIU_FILENAME', str_replace(QINIU_BASEFOLDER.'/', '', plugin_basename(__FILE__)));
define('SAE_TMP_DIR_STORAGE', SAE_TMP_PATH.'storage');
// 初始化选项
register_activation_hook(__FILE__, 'qiniu_set_options');

/**
 * 初始化选项
 */
function qiniu_set_options() {
    $options = array(
        'bucket' => "",
        'ak' => "",
    	'sk' => "",
		'hiPath'  => "",
    );
    add_option('qiniu_options', $options, '', 'yes');
}

function qiniu_admin_warnings() {
    $qiniu_options = get_option('qiniu_options', TRUE);
    $qiniu_bucket = attribute_escape($qiniu_options['bucket']);
	if ( !$qiniu_options['bucket'] && !isset($_POST['submit']) ) {
		function qiniu_warning() {
			echo "
			<div id='qiniu-warning' class='updated fade'><p><strong>".__('qiniu-Support插件已启用.')."</strong> ".sprintf(__('但你还必须 <a href="%1$s">输入你的qiniu Bucket及AK/SK</a> 它才能正常工作.'), "options-general.php?page=" . QINIU_BASEFOLDER . "/qiniu.php")."</p></div>
			";
		}
		add_action('admin_notices', 'qiniu_warning');
		return;
	} 
}
qiniu_admin_warnings();
function upload_dir($uploads){
	
	$qiniu_options = get_option('qiniu_options', TRUE);
   // $qiniu_bucket = attribute_escape($qiniu_options['bucket']);
	// $bucket = $qiniu_bucket;
	$qiniu_domain = attribute_escape($qiniu_options['domain']);

	$uploads['basedir'] = SAE_TMP_DIR_STORAGE;
	$uploads['baseurl'] = $qiniu_domain;
	$uploads['path'] = SAE_TMP_DIR_STORAGE.$uploads['subdir'];
	$uploads['url'] = SAE_TMP_DIR_STORAGE.$uploads['subdir'];
	
	return $uploads;
} 

add_filter('upload_dir', 'upload_dir');

function scs_upload($data){
	

   $wp_upload_dir = wp_upload_dir();
	$qiniu_options = get_option('qiniu_options', TRUE);
    $qiniu_bucket = attribute_escape($qiniu_options['bucket']);
   $qiniu_ak = attribute_escape($qiniu_options['ak']);
	$qiniu_sk = attribute_escape($qiniu_options['sk']);
    $bucket = $qiniu_bucket;
	if(!is_object($auth)) $auth = new Auth($qiniu_ak, $qiniu_sk);
	


	//$object =  str_replace($wp_uploads['basedir'], '', $data['file']);
	$object =  $wp_upload_dir['basedir'].'/'.basename($data['file']);
	//$object = str_replace($url, '', $object);
	
   $token = $auth->uploadToken($bucket);
   $uploadMgr = new UploadManager();
	$data = $wp_upload_dir['path'].'/'.$data['file'];
    $data = str_replace($wp_upload_dir['path'].'/', '', $data);
	 $uploadMgr->putFile($token, $data,$object);
	
  
      
	return $ret;
}


/*
 附件上传函数
 Hook 所有上传操作，上传完成后再存到云存储。
 默认设置为 public
*/

function mv_attachments_to_qiniu($data) {

	if(stripos( $data['type'], 'image/') !== false ){
		//上传缩略图
		add_filter('wp_generate_attachment_metadata', 'mv_thumbnails_to_qiniu');
	}
	
	qiniu_upload($data);

	return $data;
}
add_filter('wp_handle_upload', 'mv_attachments_to_qiniu');
 
/*
 缩略图上传函数
*/
function mv_thumbnails_to_qiniu($metadata){	
	if (isset($metadata['sizes']) && count($metadata['sizes']) > 0){
		foreach ($metadata['sizes'] as $data)
		{	
			qiniu_upload($data,true);
		}
	}
	return $data;
}




/*
 删除qiniu上的附件
*/
function del_attachments_from_qiniu($file) {
	
	$qiniu_options = get_option('qiniu_options', TRUE);
	$qiniu_bucket = attribute_escape($qiniu_options['bucket']);
	$qiniu_ak = attribute_escape($qiniu_options['ak']);
	$qiniu_sk = attribute_escape($qiniu_options['sk']);
	$bucket = $qiniu_bucket;
	if(!is_object($qiniu)) $qiniu = new Auth($qiniu_ak, $qiniu_sk);
	
	$bucketMgr = new BucketManager($qiniu);
$qiniu_domain = attribute_escape($qiniu_options['domain']);
	$upload_dir = wp_upload_dir();
	$object = str_replace($upload_dir['basedir'],'',$file);
	$object = ltrim( $object , '/' );
	$object = str_replace($qiniu_domain ,'',$object);
	//$hiPath = trim(attribute_escape($qiniu_options['hiPath']),'/');
	//if($hiPath) $object = $hiPath.'/'.$object;

	 $bucketMgr->delete($bucket,$object);
	return $file;
}
add_action('wp_delete_file', 'del_attachments_from_qiniu');

function format_qiniu_url($url) {
	$wp_upload_dir = wp_upload_dir();
	$hiPath = attribute_escape($qiniu_options['hiPath']);
	if($hiPath) $hiPath = '/' . trim($hiPath,'/');

	
	$url = str_replace($wp_upload_dir['path'], $qiniu_url, $url);
	return $url;
}
add_filter('wp_get_attachment_url', 'format_qiniu_url');

function qiniu_plugin_action_links( $links, $file ) {
	if ( $file == plugin_basename( dirname(__FILE__).'/qiniu-support.php' ) ) {
		$links[] = '<a href="options-general.php?page=' . qiniu_BASEFOLDER . '/qiniu.php">'.__('Settings').'</a>';
	}

	return $links;
}
add_filter( 'plugin_action_links', 'qiniu_plugin_action_links', 10, 2 );

function qiniu_add_setting_page() {
    add_options_page('qiniu Setting', 'qiniu Setting', 8, __FILE__, 'qiniu_setting_page');
}

add_action('admin_menu', 'qiniu_add_setting_page');

function qiniu_setting_page() {

	$options = array();
	if($_POST['bucket']) {
		$options['bucket'] = trim(stripslashes($_POST['bucket']));
	}
	if($_POST['ak']) {
		$options['ak'] = trim(stripslashes($_POST['ak']));
	}
	if($_POST['sk']) {
		$options['sk'] = trim(stripslashes($_POST['sk']));
	}
	if($_POST['domain']) {
		$options['domain'] = trim(stripslashes($_POST['domain']));
	}
	if($_POST['hiPath']) {
		$hiPath = $_POST['hiPath'];
		$hiPath = trim($hiPath);
		$hiPath = trim(stripslashes($hiPath), "/");
		$options['hiPath'] = $hiPath;
		
		//update_option('upload_path', $qiniu_url);
		update_option('upload_url_path', $qiniu_url);
	}	
	if($options !== array() ){
		update_option('qiniu_options', $options);
        
?>
<div class="updated"><p><strong>设置已保存！</strong></p></div>
<?php
    }

    $qiniu_options = get_option('qiniu_options', TRUE);
    $qiniu_bucket = attribute_escape($qiniu_options['bucket']);
    $qiniu_ak = attribute_escape($qiniu_options['ak']);
    $qiniu_sk = attribute_escape($qiniu_options['sk']);
	$qiniu_domain = attribute_escape($qiniu_options['domain']); 
	$wp_upload_dir = wp_upload_dir();
	$subdir = $wp_upload_dir['subdir'];
?>
<div class="wrap" style="margin: 10px;">
    <h2>新浪云存储 设置</h2> 
	<a href="http://club.veigen.com/qiniu-for-wordpress/4478.html" target="_blank">帮助</a>
	<a href="http://club.veigen.com/qiniu-for-wordpress/4478.html" target="_blank">反馈建议</a>
	<a href="http://club.veigen.com/qiniu-for-wordpress/4478.html" target="_blank">下载最新版本</a>
	
    <form name="form1" method="post" action="<?php echo wp_nonce_url('./options-general.php?page=' . QINIU_BASEFOLDER . '/qiniu.php'); ?>">
	  	<h3>基本设置</h3>	
        <fieldset>
            <legend>Bucket 设置</legend>
            <input type="text" id="bucket" name="bucket" value="<?php echo $qiniu_bucket;?>" placeholder="请输入云存储使用的 bucket"/>
            请先访问 <a href="https://portal.qiniu.com/signin/">七牛云存储</a> 创建 bucket 后，填写以上内容
			<p></p>
        </fieldset>
		<fieldset>
            <legend>域名设置</legend>
            <input type="text" name="domain" value="<?php echo $qiniu_domain;?>" placeholder=""/>
			访问 <a href="https://portal.qiniu.com/signin/">七牛云存储</a>，获取域名，http://开头，域名结尾不加"/"
        </fieldset>

        <fieldset>
            <legend>Access Key / API key</legend>
            <input type="text" name="ak" value="<?php echo $qiniu_ak;?>" placeholder=""/>
            <p></p>
        </fieldset>
        <fieldset>
            <legend>Secret Key</legend>
            <input type="text" name="sk" value="<?php echo $qiniu_sk;?>" placeholder=""/>
			访问 <a href="https://portal.qiniu.com/signin/">七牛云存储</a>，获取 AK/SK
        </fieldset>

	   
		
	
        <fieldset class="submit">
            <input type="submit" name="submit" value="保存更新" />
        </fieldset>
    </form>
	<h2>赞助</h2>
		<p>如果你发现这个有错误，欢迎<a href="http://club.veigen.com/qiniu-for-wordpress/4478.html" target="_blank">提问</a>!</p>
		
	<br />
</div>
<?php
}